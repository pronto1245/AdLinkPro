import PostbackManager from '@/components/postback/PostbackManager';

export default function PostbackManagement() {
  return <PostbackManager />;
}