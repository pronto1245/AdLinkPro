import{j as r}from"./ui-CkQMVfNu.js";import"./vendor-DazevGLP.js";function t(){return r.jsx("div",{className:"p-6 text-sm opacity-70",children:"Owner → Users (в разработке)"})}export{t as default};
