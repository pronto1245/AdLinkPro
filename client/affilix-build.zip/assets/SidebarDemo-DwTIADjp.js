import{j as e}from"./ui-CkQMVfNu.js";import"./vendor-DazevGLP.js";function i(){return e.jsx("div",{className:"p-6 text-sm opacity-70",children:"Sidebar demo (в разработке)"})}export{i as default};
